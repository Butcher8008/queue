package application;
	
import java.util.ArrayList;
import java.util.Random;
import java.util.Stack;

import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Main extends Application{
	
	Stage st;
	Queue a=new Queue();
	

	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage pstage) throws Exception {
		
		Label l1 =new Label("Enter Value");
		TextField t1 =new TextField();
		VBox v1 =new VBox();
		v1.getChildren().addAll(t1,l1);
		
		Button b1 =new Button ("ADD");
		b1.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event ) {
				a.enqueue(t1);
				System.out.println(Integer.toString(t1));
				
			}
		});
		HBox h1 =new HBox(v1,b1);
		
		Scene s =new Scene(h1,500,600);
		st.setTitle("QUEUE");
		st.setScene(s);
		
	}
}

