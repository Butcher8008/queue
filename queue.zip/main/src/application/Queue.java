package application;

import java.util.Scanner;

import javafx.scene.control.TextField;
import javafx.scene.control.TextInputControl;

public class Queue {

	static int front,rear,count;
	int size=4;
	int[] queue= new int[size];
	
	public void Queue()
	{
		front=0;
		rear=0;
		count = 0;
		
		for( int i=0; i<size; i++)
		{
			queue[i]=0;
		}
	}
	
	public boolean isempty()

	{
		if(count==0)
		{
			return true;
		}
		
		else
			return false;
	}
	
	public boolean isfull()
	{
		if(count==size)
		{
			return true;
		}
		else
			return false;
	}
	
	public int enqueue(int t2)
	{
		if(isfull()){
			System.out.println("Queue is full");
			return -1;
		}
		else
		{
			queue[rear]= t2;
			count++;
			rear++;
			return 1;
		}
	}
	
	public int dequeue()
	{
		if(isempty())
		{
			System.out.println("Queue is empty");
			return 0;
		}
		else
			front= (front)%size;
		count--;
		
		 for (int i = 0; i < queue.length-1; i++) {
	            queue[i]= queue[i+1];
	        }
	               queue[--rear]=0;
	              
		return front;
	}
	public void display()
	{
		if(count>0)
		{
			System.out.println("Queue has following values");
			for( int i=0; i<size; i++)
			{
				System.out.println("Queue ["+ i + "]=" +queue[i]);
				
			}
		}
		else
			System.out.println("queue is empty");
		
	}
	
	public void rev_display()
	{
		if(count>0)
		{
		System.out.println("values in reverse order");
		for( int i=size; i<0; i--)
		{
			System.out.println("Queue ["+ i + "]=" +queue[i]);
			
		}
		}
		else
			System.out.println("queue is empty");	
	}
	
	
	
	public static void main(String[] args) {
		
		/*QueueImp q= new QueueImp();
		q.enqueue(3);
		q.enqueue(6);
		q.enqueue(9);
		q.display();
		q.dequeue();
		q.display();*/
		
		
		int ch,val,flag;
		Scanner input= new Scanner(System.in);
		
		Queue q= new Queue();
		do{
			System.out.println("1: Add value in queue");
			System.out.println("2: Remove value from queue");
			System.out.println("3: Dsiplay value in queue");
			System.out.println("4: Display values in Reverse order");
			System.out.println("5: Exit");
			System.out.println("Enter your choice");
			
			ch=input.nextInt();
			
			switch(ch)
			{
			case 1:
	            System.out.println("Enter value");
	            val = input.nextInt();
				flag = q.enqueue(val);
				if(flag == 1){
					System.out.println("value entered successfully");
				}
				break;
			case 2: 
				System.out.println("value from "+ q.dequeue() + " index");
					front++;
				break;
			case 3: 
				q.display();
				break;
			case 4: 
				q.rev_display();
				break;
				
				default:
					System.out.println("wrong key");
					break;
			}
			
			
		}while(ch!=5);

	}

	

}